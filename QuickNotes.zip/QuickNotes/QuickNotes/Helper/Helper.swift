//
//  Helper.swift
//  QuickNotes
//
//  Created by Tej on 11/11/19.
//  Copyright © 2019 Tej. All rights reserved.
//
import UIKit
import Foundation
class Helper {
    func getDateString(from date : Date, with format : String, calender : Bool = false) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        if calender{
            let calendar = Calendar.current
            if calendar.isDateInYesterday(date) { return "Yesterday" }
            else if calendar.isDateInToday(date) { return "Today" }
            else if calendar.isDateInTomorrow(date) { return "Tomorrow" }
            else{
                dateFormatter.string(from: date)
            }
        }
        return dateFormatter.string(from: date)
    }
}
extension UIColor{
    static let ThemeGreen = UIColor(red: 99/255, green: 203/255, blue: 145/255, alpha: 1)
}

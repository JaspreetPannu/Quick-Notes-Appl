//
//  Note.swift
//  QuickNotes
//
//  Created by Tej on 11/11/19.
//  Copyright © 2019 Tej. All rights reserved.
//

import UIKit

class Note: NSObject {
    var note_id : String?
    var note_title : String?
    var note_desc : String?
    var date_created : Date?
    var date_modified : Date?
    var lat : Double?
    var long : Double?
    var picture : Data?
    var subject_id :String?
}
class Subjects: NSObject {
    var subject_id :String?
    var subject_name : String?
}
